package com.saifullah.firebae_reg_auth;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
